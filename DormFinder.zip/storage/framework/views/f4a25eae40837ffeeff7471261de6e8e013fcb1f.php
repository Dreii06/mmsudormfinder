<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="icon" href="/images/mmsu logo.png">
        <title>MMSU - Dorm Management | Dashboard</title>

        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="/css/COEDstyle.css">
        <!-- JS -->
        <script type="text/javascript" src="dormfindercoed.js"></script>  
    </head>
    
    <body class="antialiased">
        
    <div class="uppernav"><h3 style="color:#0C4B05;margin-left:20px;">MMSU </h3><h3> - COEDS / Proprietor Dorm Management</h3></div>
    
    <div class="topnav" id="myTopnav">
        <img style="float:left;margin-left:20px;margin-top:10px;" src="/images/mmsu logo.png"  height="60" width="60">
        <h4>MARIANO MARCOS <br> STATE UNIVERSITY</h4>
        <div class="titleheader">DORM</div>
    </div>
                
    <div class="verticalnav">
        <ul>
            <li class="username"><?php echo e(Auth::guard('manager')->user()->dorm_name); ?></li>
            <li><a href="/manager/dashboard"> <img src="https://img.icons8.com/fluent-systems-regular/96/000000/home.png"/> Home</a></li>
            <li><a href="/manager/listapplicants"> <img src="https://img.icons8.com/fluent-systems-regular/50/000000/parse-resume.png"/> Applicants</a></li>
            <li><a href="/manager/listoccupants"><img src="https://img.icons8.com/fluent-systems-regular/96/000000/user-rights.png"/> Occupants</a></li>
            <li><a class="active" href="/manager/viewdorm/<?php echo e(Auth::guard('manager')->user()->id); ?>"><img src="https://img.icons8.com/fluent-systems-regular/96/000000/department.png"/> Dorm</a></li>
            <li><a href="/manager/contact"><img src="https://img.icons8.com/fluent-systems-regular/96/000000/info-squared.png"/> Contact</a></li><br><br>
            <li><a href="" style="color:red;"><img src="https://img.icons8.com/ios-filled/50/000000/exit.png"/>Log Out</a></li>
        </ul>    
    </div>

    <div class="updatedormcontainer">
    <form style="width:100%;">

    <label for="fname">First Name</label>
    <label for="fname">Middle Name</label>
    <label for="fname">Last Name</label><br>

    <input type="text" id="fname" name="fname" value="<?php echo e($details->first_name); ?>" style="width: 25%;" class="inputapp">
    <input type="text" id="fname" name="fname" value="<?php echo e($details->middle_name); ?>" style="width: 25%;" class="inputapp">
    <input type="text" id="fname" name="fname" value="<?php echo e($details->last_name); ?>" style="width: 25%;" class="inputapp"><br><br>

    <label for="dname">Dorm Name</label>
    <label for="contact">Contact</label>
    <label for="quantity">Available space</label><br>

    <input type="tel" id="fname" name="dname" value="<?php echo e($details->dorm_name); ?>" style="width: 25%;" class="inputapp" >
    <input type="text" id="fname" name="contact" value="<?php echo e($details->mobile_num); ?>" style="width: 25%;" class="inputapp">
    <input type="number" id="quantity" name="quantity" value="<?php echo e($details->available_space); ?>" style="width: 25%;" class="inputapp" min="0"><br><br>

    <label for="brgy">Barangay</label>
    <label for="st">Street</label><br>

    <input type="text" id="brgy" name="fname" value="<?php echo e($details->barangay); ?>" style="width: 25%;" class="inputapp">
    <input type="text" id="st" name="fname" value="<?php echo e($details->street); ?>" style="width: 25%;" class="inputapp"><br><br>

    <label for="hn">House Number</label>
    <label for="nl">Nearest Landmark</label><br>

    <input type="text" id="hn" name="fname" value="<?php echo e($details->house_num); ?>" style="width: 25%;" class="inputapp">
    <input type="text" id="nl" name="fname" value="<?php echo e($details->nearest); ?>" style="width: 25%;" class="inputapp"><br><br>

    <label for="fname">Short Description</label><br>
    <textarea readonly><?php echo e($details->description); ?></textarea><br><br>

    </form>

    <label style="margin-left:1.5%;" for="fname">Amenities</label>
    <table class="viewdormtable" id="room">
        <tr>
            <th>Amenities</th>
        </tr>
        <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="readapp"><?php echo e($amenity->amenities); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br><br>

    <table class="viewdormtable" id="room">
        <tr>
            <th>Room Type</th>
            <th>Price</th>
        </tr>
        <?php $__currentLoopData = $room_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="readapp"><?php echo e($types->room_type); ?></td>
            <td class="readapp"><?php echo e($types->price); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br><br>

    <label style="margin-left:1.5%;" for="slide">Uploaded Images</label>
    <div class="slide-container" id="slide">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="/images/<?php echo e($image->filename); ?>" />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <a href="updateimage"><button type="button" class="greenbutton" style="margin-right:20%;margin-top:10px;"> UPDATE IMAGE</button></a>
    <a href="/manager/updatedorm/<?php echo e(Auth::guard('manager')->user()->id); ?>"><button type="button" class="secondyellowbutton" style="margin-top:10px;margin-right:2%;">UPDATE FORM</button></a>
</div><?php /**PATH C:\Users\Dreii\Documents\laravel\DormFinder\resources\views/manager/viewdorm.blade.php ENDPATH**/ ?>