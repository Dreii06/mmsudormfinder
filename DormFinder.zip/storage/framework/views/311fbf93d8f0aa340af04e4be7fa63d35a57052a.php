<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MMSU - Dorm Finder | Profile</title>

        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="StudentStyle.css">  
        <!-- JavaScript -->
        <script src="/studentDormFinder.js"></script>
        <link rel="icon" href="/images/mmsu logo.png">
        
    </head>
    
    <body class="antialiased">

    <div class="uppernav"> <h3 style="margin-left:20px;color:#0C4B05;">MMSU </h3><h3> - Dorm Finder</h3></div>
    
    <div class="topnav" id="myTopnav">
        <img style="float:left;margin-left:20px;margin-top:10px;" src="/images/mmsu logo.png"  height="60" width="60">
        <h4>MARIANO MARCOS <br> STATE UNIVERSITY</h4>
            <a href="/dashboard">CONTACT</a>
            <a href="#contact">ABOUT US</a>
            <a href="dorm">LIST OF DORMS</a>

            <div class="usernav">
            <img style="float:right;margin-top:15px;" src="/images/user.png"  height="30" width="30">
                <div class="menu">
                    <ul><li>
                     <a href="#" style="float:right;margin:10px 0px 0px 10px;"><?php echo e(Auth::user()->stud_number); ?></a>
                        <ul>
                        <li><a href="/profilestudent">Profile</a></li><br>
                        <li><a href="applicationlist">Application List</a></li><br>
                        <li><a href="#">Log Out</a></li>
                        </ul>
                    </ul></li>
            </div></div>
    </div>

    <div class="header">
        <h1></h1>
    </div>

    <form action="/profilestudent" method="POST">
    <?php echo csrf_field(); ?>
    <label for="fname">Full Name</label>
            <input type="text" id="fname" name="name" value="<?php echo e(Auth::user()->name); ?>" style="width: 400px;" class="inputapp">
        <label style="margin-left:30px;" for="fstudentid">Student Number</label>
            <input type="text" id="fstudentid" name="stud_id" value="<?php echo e(Auth::user()->stud_number); ?>" style="width: 400px;" class="inputapp" ><br><br>
        <label for="sex">Sex</label>
            <input type="text" id="sex" name="sex" value="<?php echo e(Auth::user()->sex); ?>" style="width: 400px;" class="inputapp">
        <label style="margin-left:30px;" for="email">Email</label>
            <input type="email" id="email" value="<?php echo e(Auth::user()->email); ?>" style="width: 400px;" class="inputapp"><br><br>
        <label for="number">Mobile Number</label>
            <input type="tel" id="number" name="mobile" value="<?php echo e(Auth::user()->mobile_number); ?>" style="width: 400px;" class="inputapp">
        <label style="margin-left:30px;" for="number">Contact of Guardian</label>
            <input type="tel" id="number" name="guardian" value="<?php echo e(Auth::user()->guardian_number); ?>" style="width: 400px;" class="inputapp"><br><br>
        <label for="birthday">Date of Birth</label>
            <input type="date" id="birthday" name="dob" value="<?php echo e(Auth::user()->date_of_birth); ?>" style="width: 400px;" class="inputapp">
        <label style="margin-left:30px;" for="birthday">Address</label>
            <input type="text" id="birthday" name="address" value="<?php echo e(Auth::user()->address); ?>" style="width: 400px;" class="inputapp"><br><br><br><br>
        <label for="college">College:</label>
        <select name="college" id="room" style="width: 200px;"class="inputapp">
            <option value="cas">CAS</option>
            <option value="coe">COE</option>
            <option value="cbea">CBEA</option>
            <option value="chs">CHS</option>
        </select><br><br>
        <label for="course">Course:</label>
        <select name="course" id="room" style="width: 200px;"class="inputapp">
            <option value="cas">CAS</option>
            <option value="coe">COE</option>
            <option value="cbea">CBEA</option>
            <option value="chs">CHS</option>
        </select><br><br>
       

        <a href="home"><button type="button" class="greenbutton" style="margin-top:20px;">CANCEL</button></a>
        <button type="submit" onclick="updateProfileFunction()" class="secondyellowbutton" style="margin-right:10px;margin-top:20px;"> UPDATE</button>
        
    </form>

    </body>
</html><?php /**PATH C:\Users\Dreii\Documents\laravel\DormFinder\resources\views//profilestudent.blade.php ENDPATH**/ ?>